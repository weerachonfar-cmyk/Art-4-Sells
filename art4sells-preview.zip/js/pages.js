/* One renderer per page. Each reads via A4S.api / A4S.store only. */
(function(){
var $=function(s){return document.querySelector(s)},U=A4S.ui,API=A4S.api,ST=A4S.store;
var qs=function(k){return new URLSearchParams(location.search).get(k)};
var k=function(n){return n>=1000?(n/1000).toFixed(1).replace(".0","")+"K":String(n)};
var opts=function(a,all){return (all?'<option value="">'+all+'</option>':'')+a.map(function(x){return '<option value="'+x[0]+'">'+x[1]+'</option>'}).join("")};
A4S.pages={
home:function(){
 var st={by:"artwork",q:"",cat:"",rating:"",max:"",sort:"",page:1,artist:qs("artist")||""};
 var feat=A4S.artworks.filter(function(w){return w.rating>=4.8&&w.status!=="Sold"});
 $("#app").innerHTML='<div class="wrap"><section><h1>Art worth collecting.</h1><p class="mute">Original illustration, 3D and game assets from independent artists.</p><div class="rail">'+feat.map(U.card).join("")+'</div></section>'
 +'<section id="results"><h2>Discover</h2><form class="search" id="sf"><div class="srow"><select name="by">'+opts([["artwork","Artwork"],["artist","Artist"],["tag","Tag"]])+'</select>'
 +'<input name="q" placeholder="Search by title, artist or tag" style="flex:1;min-width:180px"><button class="btn">Search</button></div>'
 +'<div class="srow"><select name="cat">'+opts(A4S.cats.map(function(c){return [c,c]}),"All categories")+'</select>'
 +'<select name="rating">'+opts([["4.5","4.5 and up"],["4.8","4.8 and up"]],"Any rating")+'</select>'
 +'<select name="max">'+opts([["500","Up to \u0e3f500"],["1000","Up to \u0e3f1,000"],["2000","Up to \u0e3f2,000"]],"Any price")+'</select>'
 +'<select name="sort">'+opts([["low","Price: low to high"],["high","Price: high to low"],["rating","Top rated"]],"Sort: Featured")+'</select></div></form><div id="grid"></div></section>'
 +'<section id="promos"><h2>Featured Promotions</h2><div class="promos">'+A4S.promos.map(function(p,i){var c=A4S.pal[i+1];return '<a class="promo" href="index.html?artist='+p.q+'#results" style="background:linear-gradient(135deg,'+c[0]+','+c[1]+')"><b>'+p.big+'</b><span>'+U.esc(p.who)+'</span><small>'+p.txt+'</small><span class="btn sm ghost" style="color:#fff;border-color:#fff;align-self:flex-start;margin-top:10px">Explore</span></a>'}).join("")+'</div></section>'
 +'<section><h2>Artists of the Week</h2><div class="grid">'+A4S.artists.map(function(a){return '<a class="box" href="artist.html?id='+a.id+'"><div class="by">'+U.avatar(a)+U.esc(a.name)+'</div><p class="mute small">'+U.esc(a.role)+'</p><p>'+U.stars(a.rating)+'</p></a>'}).join("")+'</div></section></div>';
 var f=$("#sf");
 function draw(){var r=API.artworks(Object.assign({},st,{size:8}));st.page=r.page;
  $("#grid").innerHTML=(r.total?'<p class="mute small" style="margin-bottom:12px">'+r.total+' artworks</p><div class="grid">'+r.items.map(U.card).join("")+'</div>':'<p class="mute">No artwork matches. Try clearing a filter.</p>')
  +(r.pages>1?'<div class="pager"><button class="btn ghost" data-pg="-1"'+(r.page<2?' disabled':'')+'>Previous</button><span>'+r.page+' / '+r.pages+'</span><button class="btn ghost" data-pg="1"'+(r.page>=r.pages?' disabled':'')+'>Next</button></div>':'')}
 function read(){var d=new FormData(f);["by","q","cat","rating","max","sort"].forEach(function(n){st[n]=d.get(n)});st.page=1;draw()}
 f.addEventListener("input",read);f.addEventListener("submit",function(e){e.preventDefault();read()});
 $("#grid").addEventListener("click",function(e){var b=e.target.closest("[data-pg]");if(b){st.page+=+b.dataset.pg;draw()}});
 draw();
},
artwork:function(){
 var w=API.artwork(qs("id"));
 if(!w){$("#app").innerHTML='<div class="wrap"><section><h2>Artwork not found</h2><a class="btn" href="index.html">Back to Explore</a></section></div>';return}
 var a=API.artist(w.artist),ok=w.status==="Available",dis=ok?"":" disabled",lim=w.type==="LIMITED";
 var more=A4S.artworks.filter(function(x){return x.artist===a.id&&x.id!==w.id}).slice(0,4);
 $("#app").innerHTML='<div class="wrap"><section class="detail"><div class="thumb wm"><img alt="'+U.esc(w.title)+'" src="'+U.art(w.seed)+'"></div><div>'
 +'<h1>'+U.esc(w.title)+'</h1><a class="by" href="artist.html?id='+a.id+'">'+U.avatar(a)+U.esc(a.name)+'</a>'
 +'<p class="price">'+U.money(w.price)+'<small>'+U.stars(w.rating)+'</small></p>'
 +'<p><span class="pill '+w.status+'">'+w.status+'</span> <span class="pill">'+(lim?"LIMITED":"UNLIMITED LICENSE")+'</span> <span class="pill">'+U.esc(w.cat)+'</span></p>'
 +'<p>'+U.esc(w.desc)+'</p><p>'+w.tags.map(function(t){return '<span class="pill">#'+U.esc(t)+'</span> '}).join("")+'</p>'
 +'<div class="acts"><button class="btn" data-add="'+w.id+'"'+dis+'>Add to Cart</button><button class="btn ghost" data-buy="'+w.id+'"'+dis+'>Buy Now</button>'
 +'<button class="ib heart-btn'+(ST.inWish(w.id)?' on':'')+'" style="border:1px solid var(--line);border-radius:50%" data-heart="'+w.id+'" aria-label="Wishlist">'+U.icon("heart")+'</button></div>'
 +'<p class="mute small">'+(lim?"Limited works are sold once and locked while a payment is pending.":"Unlimited licence: can be sold repeatedly. The original file is delivered after purchase.")+'</p></div></section>'
 +(more.length?'<section><h2>More from '+U.esc(a.name)+'</h2><div class="grid">'+more.map(U.card).join("")+'</div></section>':'')+'</div>';
},
artist:function(){
 var a=API.artist(qs("id"))||A4S.artists[0],fl=ST.isFollowing(a.id),works=A4S.artworks.filter(function(w){return w.artist===a.id});
 $("#app").innerHTML='<div class="wrap"><section><div class="ph">'+U.avatar(a)+'<div><h1 style="margin:0">'+U.esc(a.name)+'</h1><p>'+U.esc(a.role)+'</p><p>'+U.stars(a.rating)+' &nbsp; '+k(a.followers+(fl?1:0))+' followers</p></div></div>'
 +'<p style="max-width:560px;margin:18px 0">'+U.esc(a.bio)+'</p><button class="btn'+(fl?' ghost':'')+'" data-follow="'+a.id+'">'+(fl?"Following":"Follow")+'</button> '
 +(a.commission?'<a class="btn ghost" href="#commissions">Commission</a>':'<span class="pill">Commissions closed</span>')+'</section>'
 +'<section id="commissions"><h2>Commissions</h2>'+(a.commission?'<div class="tiers">'+A4S.tiers.map(function(t){return '<div class="box"><h2 style="margin-bottom:6px">'+t.n+'</h2><p>Starting at '+U.money(t.p)+'</p><p class="mute small">Delivery: '+t.d+'<br>Revisions: '+t.r+'</p><button class="btn ghost sm" data-toast="Commission flow arrives in Phase 4">View Commission</button></div>'}).join("")+'</div>':'<p class="mute">This artist is not taking commissions right now.</p>')+'</section>'
 +'<section><h2>Artwork</h2><div class="grid">'+works.map(U.card).join("")+'</div></section></div>';
},
wishlist:function(){
 var items=ST.wish().map(function(id){return API.artwork(id)}).filter(Boolean);
 $("#app").innerHTML='<div class="wrap"><section><h2>My Wishlist</h2>'+(items.length?'<div class="grid">'+items.map(U.card).join("")+'</div>':'<p class="mute" style="margin-bottom:14px">Tap the heart on any artwork to save it here.</p><a class="btn" href="index.html">Browse artwork</a>')+'</section></div>';
},
cart:function(){
 var c=ST.cart(),total=0,ids=Object.keys(c).filter(function(id){return API.artwork(id)});
 var rows=ids.map(function(id){var w=API.artwork(id),a=API.artist(w.artist);total+=w.price*c[id];
  return '<div class="row"><img alt="" src="'+U.art(w.seed)+'"><div style="flex:1"><a class="t" href="artwork.html?id='+id+'">'+U.esc(w.title)+'</a><div class="mute small">'+U.esc(a.name)+', '+w.type+'</div></div>'
  +(w.type==="UNLIMITED"?'<span><button class="btn ghost sm" data-qty="'+id+'" data-d="-1">-</button> '+c[id]+' <button class="btn ghost sm" data-qty="'+id+'" data-d="1">+</button></span>':'<span class="mute small">Qty 1</span>')
  +'<b>'+U.money(w.price*c[id])+'</b><button class="ib" data-rm="'+id+'" aria-label="Remove">&#10005;</button></div>'}).join("");
 $("#app").innerHTML='<div class="wrap"><section><h2>Cart</h2>'+(ids.length?rows+'<div class="sum"><div><span>Subtotal</span><span>'+U.money(total)+'</span></div><div><b>Total</b><b>'+U.money(total)+'</b></div><button class="btn" data-toast="Mock checkout: payment is not connected yet">Checkout</button></div>':'<p class="mute" style="margin-bottom:14px">Your cart is empty.</p><a class="btn" href="index.html">Browse artwork</a>')+'</section></div>';
},
auth:function(mode){
 var reg=mode==="register";
 $("#app").innerHTML='<div class="wrap"><section><form class="form" id="af" novalidate><h1>'+(reg?"Create account":"Welcome back")+'</h1>'
 +(reg?'<input name="name" placeholder="Display name" autocomplete="nickname">':'')
 +'<input name="email" type="email" placeholder="Email" autocomplete="email"><input name="password" type="password" placeholder="Password" autocomplete="'+(reg?'new-password':'current-password')+'">'
 +(reg?'<input name="confirm" type="password" placeholder="Confirm password" autocomplete="new-password">':'')
 +'<select name="role">'+opts([["USER","Role: USER (buyer)"],["ARTIST","Role: ARTIST"]].concat(reg?[]:[["ADMIN","Role: ADMIN (demo)"]]))+'</select>'
 +'<p class="err" id="err"></p><button class="btn">'+(reg?"Create Account":"Login")+'</button>'
 +'<p class="mute small">'+(reg?'Have an account? <a href="login.html"><u>Login</u></a>':'New here? <a href="register.html"><u>Register</u></a>')+'. Mock auth: the password is never stored.</p></form></section></div>';
 $("#af").addEventListener("submit",function(e){e.preventDefault();var d=Object.fromEntries(new FormData(e.target)),m=A4S.auth.signIn(d);
  if(m){$("#err").textContent=m;return}location.href=d.role==="ADMIN"?"admin.html":"index.html"});
},
login:function(){A4S.pages.auth("login")},
register:function(){A4S.pages.auth("register")},
admin:function(){
 var usr=ST.user(),P=A4S.pending,S=A4S.stats;
 if(!usr||usr.role!=="ADMIN"){$("#app").innerHTML='<div class="wrap"><section><h2>Admins only</h2><p class="mute" style="margin-bottom:14px">Role check: log in with the ADMIN demo role to open the dashboard.</p><a class="btn" href="login.html">Login</a></section></div>';return}
 var tabs=["Dashboard","Users","Artwork Approval","Reviews","Reports","Blacklist","IP Block","Audit Logs"],tab=qs("tab")||"Dashboard",body;
 var pend=P.filter(function(p){return p.status==="Pending"}).length;
 if(tab==="Dashboard")body='<div class="stats">'+[["Total Users",S.users],["Total Artists",S.artists],["Total Artworks",S.artworks],["Pending Approval",pend],["Total Orders",S.orders],["Reports",S.reports]].map(function(x){return '<div class="stat"><span class="mute">'+x[0]+'</span><b>'+x[1].toLocaleString()+'</b></div>'}).join("")+'</div>';
 else if(tab==="Artwork Approval")body='<div class="tw"><table><tr><th>Artwork</th><th>Artist</th><th>Submitted</th><th>Status</th><th></th></tr>'+P.map(function(p){return '<tr><td>'+U.esc(p.title)+'</td><td>'+U.esc(p.artist)+'</td><td>'+p.date+'</td><td><span class="pill '+p.status+'">'+p.status+'</span></td><td>'+(p.status==="Pending"?'<button class="btn sm" data-decide="'+p.id+'" data-v="Approved">Approve</button> <button class="btn ghost sm" data-decide="'+p.id+'" data-v="Rejected">Reject</button>':"")+'</td></tr>'}).join("")+'</table></div>';
 else body='<div class="box"><p class="mute">'+tab+' needs the Python backend. Planned for Phase 2 to 5.</p></div>';
 $("#app").innerHTML='<div class="wrap"><section class="adm"><nav class="side">'+tabs.map(function(t){return '<a class="'+(t===tab?"on":"")+'" href="admin.html?tab='+encodeURIComponent(t)+'">'+t+'</a>'}).join("")+'</nav><div><h2>'+tab+'</h2>'+body+'</div></section></div>';
}
};
})();
