/* State + data-access. Phase 2: swap A4S.api / A4S.auth internals for fetch() calls. No secrets here. */
A4S.store={
 get:function(k,d){try{var v=localStorage.getItem("a4s_"+k);return v===null?d:JSON.parse(v)}catch(e){return d}},
 set:function(k,v){try{localStorage.setItem("a4s_"+k,JSON.stringify(v))}catch(e){}},
 wish:function(){return this.get("wish",[])},
 inWish:function(id){return this.wish().indexOf(id)>-1},
 toggleWish:function(id){var w=this.wish(),i=w.indexOf(id);if(i>-1)w.splice(i,1);else w.push(id);this.set("wish",w);return i<0},
 cart:function(){return this.get("cart",{})},
 addCart:function(id){var c=this.cart(),w=A4S.api.artwork(id);c[id]=(w&&w.type==="LIMITED")?1:(c[id]||0)+1;this.set("cart",c)},
 setQty:function(id,q){var c=this.cart();if(q>0)c[id]=q;else delete c[id];this.set("cart",c)},
 cartCount:function(){var c=this.cart();return Object.keys(c).reduce(function(s,k){return s+c[k]},0)},
 user:function(){return this.get("user",null)},
 isFollowing:function(id){return this.get("follow",[]).indexOf(id)>-1},
 toggleFollow:function(id){var f=this.get("follow",[]),i=f.indexOf(id);if(i>-1)f.splice(i,1);else f.push(id);this.set("follow",f)}
};
A4S.api={
 artwork:function(id){return A4S.artworks.find(function(w){return w.id===id})},
 artist:function(id){return A4S.artists.find(function(a){return a.id===id})},
 artworks:function(o){
  o=o||{};var q=(o.q||"").trim().toLowerCase(),by=o.by||"artwork";
  var list=A4S.artworks.filter(function(w){
   var hay=by==="artist"?A4S.api.artist(w.artist).name:by==="tag"?w.tags.join(" "):w.title;
   return (!q||hay.toLowerCase().indexOf(q)>-1)&&(!o.cat||w.cat===o.cat)&&(!o.rating||w.rating>=+o.rating)&&(!o.max||w.price<=+o.max)&&(!o.artist||w.artist===o.artist);
  });
  var by2={low:function(a,b){return a.price-b.price},high:function(a,b){return b.price-a.price},rating:function(a,b){return b.rating-a.rating}}[o.sort];
  if(by2)list.sort(by2);
  var size=o.size||8,pages=Math.max(1,Math.ceil(list.length/size)),page=Math.min(Math.max(1,o.page||1),pages);
  return {items:list.slice((page-1)*size,page*size),total:list.length,page:page,pages:pages};
 }
};
A4S.auth={ /* mock: validates input, never stores the password */
 check:function(f){
  if(f.name!==undefined&&f.name.trim().length<2)return "Display name must be at least 2 characters.";
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email||""))return "Enter a valid email address.";
  if((f.password||"").length<8)return "Password must be at least 8 characters.";
  if(f.confirm!==undefined&&f.confirm!==f.password)return "Passwords do not match.";
  return "";
 },
 signIn:function(f){var e=this.check(f);if(e)return e;A4S.store.set("user",{name:f.name||f.email.split("@")[0],email:f.email,role:f.role||"USER"});return ""},
 signOut:function(){A4S.store.set("user",null)}
};
