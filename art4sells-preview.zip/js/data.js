/* Mock data. Phase 2: replace with JSON/API; only A4S.api (store.js) reads this. */
var A4S=window.A4S={};
A4S.pal=[["#1d2b64","#f8cdda","#ffd6a5"],["#0f2027","#2c5364","#e8c07d"],["#3a1c71","#d76d77","#ffaf7b"],["#134e5e","#71b280","#f1f2b5"],["#232526","#b79891","#f3e7e9"],["#41295a","#2f0743","#e0a96d"],["#114357","#f29492","#fdeb71"],["#283048","#859398","#f5ebe0"]];
A4S.cats=["Illustration","Digital Painting","3D Art","Character","Game Asset","Concept Art","Photography","Other"];
A4S.artists=[
{id:"a1",name:"Mika Sorn",role:"Illustrator & Digital Artist",rating:4.8,followers:1200,commission:true,bio:"Bangkok-based illustrator painting quiet, ink-soaked night scenes and character portraits."},
{id:"a2",name:"Kenji Aoi",role:"3D Artist & Game Asset Designer",rating:4.7,followers:3400,commission:true,bio:"Builds stylised low-poly worlds and production-ready game props for indie teams."},
{id:"a3",name:"Nara Wong",role:"Concept Artist",rating:4.9,followers:860,commission:false,bio:"Environment and creature concepts for film, games and tabletop stories."},
{id:"a4",name:"Lumi Pranee",role:"Photographer & Texture Artist",rating:4.6,followers:540,commission:true,bio:"Captures surfaces, light and weather, then turns them into seamless texture packs."}];
A4S.artworks=[
["Moonlit Koi","a1","Illustration",1200,4.9,"LIMITED","Available",["koi","night","ink"],"Ink and gouache koi drifting under a paper-white moon. One edition only."],
["Lantern Street","a1","Digital Painting",900,4.8,"LIMITED","Available",["city","lantern","night"],"A rain-soaked alley glowing with hand-painted lanterns."],
["Fox Ranger","a1","Character",650,4.7,"UNLIMITED","Available",["fox","fantasy","character"],"Forest ranger character sheet with full-colour and line-art layers."],
["Stone Golem Kit","a2","3D Art",1490,4.8,"UNLIMITED","Available",["golem","lowpoly","rigged"],"Rigged low-poly golem with three texture sets. Commercial licence included."],
["Dungeon Prop Pack","a2","Game Asset",990,4.6,"UNLIMITED","Available",["dungeon","props","modular"],"48 modular dungeon props with game-ready FBX files and PNG atlases."],
["Floating Isles","a2","3D Art",2200,4.9,"LIMITED","Processing",["island","sky","render"],"A cinematic render of drifting islands at dawn. Payment in progress."],
["Ashen Citadel","a3","Concept Art",1800,5.0,"LIMITED","Available",["castle","environment","matte"],"Matte-painted fortress rising from volcanic plains."],
["Tide Wraith","a3","Concept Art",1350,4.8,"LIMITED","Sold",["creature","sea","design"],"Creature study with silhouette exploration and colour keys."],
["Wet Stone Textures","a4","Game Asset",450,4.5,"UNLIMITED","Available",["texture","stone","seamless"],"12 seamless 4K PBR stone textures shot after monsoon rain."],
["Golden Hour, Ayutthaya","a4","Photography",800,4.7,"LIMITED","Available",["photo","temple","sunset"],"Fine-art print file of ancient brick stupas at last light."],
["Paper Garden","a1","Illustration",700,4.6,"UNLIMITED","Available",["flowers","paper","pastel"],"Layered paper-cut botanicals in a soft pastel palette."],
["Neon Courier","a3","Character",1100,4.7,"LIMITED","Available",["cyberpunk","neon","character"],"Motorbike courier in a neon-soaked megacity, with full concept breakdown."]
].map(function(r,i){return {id:"w"+(i+1),title:r[0],artist:r[1],cat:r[2],price:r[3],rating:r[4],type:r[5],status:r[6],tags:r[7],desc:r[8],seed:i}});
A4S.tiers=[{n:"Head Shot",p:500,d:"3-7 days",r:2},{n:"Half Body",p:800,d:"5-10 days",r:2},{n:"Full Body",p:1500,d:"7-14 days",r:3}];
A4S.promos=[{big:"50% OFF",who:"Mika Sorn",txt:"Selected digital artwork",q:"a1"},{big:"Bundle -30%",who:"Kenji Aoi",txt:"Game asset packs",q:"a2"},{big:"New drop",who:"Lumi Pranee",txt:"Texture collection",q:"a4"}];
A4S.pending=[{id:"p1",title:"Sakura Mech",artist:"Kenji Aoi",date:"2026-09-28",status:"Pending"},{id:"p2",title:"Salt Flat Dreams",artist:"Lumi Pranee",date:"2026-09-29",status:"Pending"},{id:"p3",title:"Ember Fox",artist:"Mika Sorn",date:"2026-09-30",status:"Pending"},{id:"p4",title:"Glass Harbour",artist:"Nara Wong",date:"2026-09-30",status:"Pending"}];
A4S.stats={users:1284,artists:96,artworks:412,orders:238,reports:7};
