/* Bootstrap: header, page render, global click actions. */
(function(){
 var pg=document.body.dataset.page,S=A4S.store,U=A4S.ui;
 A4S.refresh=function(){document.getElementById("hdr").innerHTML=U.header()};
 A4S.refresh();
 if(A4S.pages[pg])A4S.pages[pg]();
 document.addEventListener("click",function(e){
  var t=e.target,el,on=function(a){el=t.closest("["+a+"]");return el};
  if(on("data-heart")){e.preventDefault();var v=S.toggleWish(el.dataset.heart);el.classList.toggle("on",v);A4S.refresh();U.toast(v?"Saved to wishlist":"Removed from wishlist");if(pg==="wishlist")A4S.pages.wishlist()}
  else if(on("data-add")){S.addCart(el.dataset.add);A4S.refresh();U.toast("Added to cart")}
  else if(on("data-buy")){S.addCart(el.dataset.buy);location.href="cart.html"}
  else if(on("data-rm")){S.setQty(el.dataset.rm,0);A4S.refresh();A4S.pages.cart()}
  else if(on("data-qty")){var id=el.dataset.qty;S.setQty(id,(S.cart()[id]||0)+ +el.dataset.d);A4S.refresh();A4S.pages.cart()}
  else if(on("data-follow")){S.toggleFollow(el.dataset.follow);A4S.pages.artist()}
  else if(on("data-decide")){A4S.pending.forEach(function(p){if(p.id===el.dataset.decide)p.status=el.dataset.v});A4S.pages.admin()}
  else if(on("data-toast"))U.toast(el.dataset.toast);
  else if(t.closest("#menuBtn")||(t.closest("#profile")&&S.user())){e.preventDefault();document.getElementById("menu").classList.toggle("open")}
  else if(t.closest("#logout")){e.preventDefault();A4S.auth.signOut();location.href="index.html"}
  else{var m=document.getElementById("menu");if(m&&!t.closest("#menu"))m.classList.remove("open")}
 });
})();
